import React, { useState } from 'react';
import { motion } from 'framer-motion';

const Reservations: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    date: '',
    guests: '2',
    request: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // Logic to send to backend would go here
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-16 flex flex-col md:flex-row gap-16">
      <div className="flex-1">
        <h1 className="font-serif text-5xl text-white mb-6">Secure Your Table</h1>
        <p className="text-gray-400 mb-8">
          Reservations are recommended 2 weeks in advance for weekend dining. 
          Please inform us of any dietary restrictions or political affiliations you wish to avoid discussing.
        </p>
        <div className="space-y-4">
          <div className="p-6 border border-white/10 bg-white/5 rounded-lg">
            <h3 className="text-oceane-gold font-bold mb-2">Dress Code</h3>
            <p className="text-gray-400 text-sm">Smart Casual / Avant-Garde.</p>
          </div>
          <div className="p-6 border border-white/10 bg-white/5 rounded-lg">
            <h3 className="text-oceane-gold font-bold mb-2">Cancellation</h3>
            <p className="text-gray-400 text-sm">Please cancel at least 24 hours prior to avoid a fee.</p>
          </div>
        </div>
      </div>

      <div className="flex-1 bg-white/5 p-8 rounded-xl border border-white/10 backdrop-blur-md">
        {submitted ? (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-20">
            <h2 className="text-2xl font-serif text-oceane-gold mb-4">Request Received</h2>
            <p className="text-gray-300">Our concierge will confirm your reservation via email shortly.</p>
            <p className="mt-4 text-sm text-gray-500">Prepare your arguments.</p>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-gray-400 mb-2">Full Name</label>
              <input 
                required 
                name="name"
                value={formData.name}
                onChange={handleChange}
                type="text" 
                className="w-full bg-black/20 border border-white/10 rounded-md p-3 text-white focus:border-oceane-gold outline-none focus:ring-1 focus:ring-oceane-gold transition-all" 
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-bold text-gray-400 mb-2">Date</label>
                <input 
                  required 
                  name="date"
                  value={formData.date}
                  onChange={handleChange}
                  type="date" 
                  className="w-full bg-black/20 border border-white/10 rounded-md p-3 text-white focus:border-oceane-gold outline-none" 
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-400 mb-2">Guests</label>
                <select 
                  name="guests"
                  value={formData.guests}
                  onChange={handleChange}
                  className="w-full bg-black/20 border border-white/10 rounded-md p-3 text-white focus:border-oceane-gold outline-none"
                >
                  {[1,2,3,4,5,6,7,8].map(n => <option key={n} value={n}>{n} Guests</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-400 mb-2">Email</label>
              <input 
                required 
                name="email"
                type="email" 
                value={formData.email}
                onChange={handleChange}
                className="w-full bg-black/20 border border-white/10 rounded-md p-3 text-white focus:border-oceane-gold outline-none" 
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-400 mb-2">Special Requests</label>
              <textarea 
                name="request"
                value={formData.request}
                onChange={handleChange}
                rows={4} 
                className="w-full bg-black/20 border border-white/10 rounded-md p-3 text-white focus:border-oceane-gold outline-none" 
              />
            </div>

            <button type="submit" className="w-full py-4 bg-oceane-gold text-oceane-dark font-bold tracking-widest hover:bg-white transition-colors">
              CONFIRM BOOKING
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default Reservations;