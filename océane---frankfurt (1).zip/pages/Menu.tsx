import React, { useState } from 'react';
import { getCuratorRecommendation } from '../services/geminiService';
import { CuratorMood, CuratorRecommendation, MenuItem } from '../types';
import { motion } from 'framer-motion';
import { Sparkles, Loader2 } from 'lucide-react';

const MENU_DATA: Record<string, MenuItem[]> = {
  starters: [
    { id: '1', name: 'Oyster & Pearl', description: 'Gillardeau oysters, tapioca pearls, champagne foam.', price: '€28', category: 'starter' },
    { id: '2', name: 'Beef Tartare "Marx"', description: 'Hand-cut beef, smoked egg yolk, revolutionary red pepper essence.', price: '€32', category: 'starter' },
    { id: '3', name: 'Velouté of White Asparagus', description: 'Truffle oil, chive dust, edible gold leaf.', price: '€24', category: 'starter' }
  ],
  mains: [
    { id: '4', name: 'The Blue Lobster', description: 'Brittany lobster, saffron risotto, coral butter sauce.', price: '€75', category: 'main' },
    { id: '5', name: 'Venison Loin', description: 'Juniper crust, parsnip purée, blackberry jus.', price: '€58', category: 'main' },
    { id: '6', name: 'Turbot "Diplomat"', description: 'Wild turbot, caviar sauce, confit leeks.', price: '€62', category: 'main' }
  ],
  desserts: [
    { id: '7', name: 'Sphere of Democracy', description: 'Chocolate sphere, molten raspberry core, gold hammer to break.', price: '€22', category: 'dessert' },
    { id: '8', name: 'Frankfurt Crown Cake', description: 'Deconstructed, buttercream, cherry brandy, croquant.', price: '€18', category: 'dessert' }
  ]
};

const Menu: React.FC = () => {
  const [selectedMood, setSelectedMood] = useState<CuratorMood | null>(null);
  const [recommendation, setRecommendation] = useState<CuratorRecommendation | null>(null);
  const [loading, setLoading] = useState(false);

  const handleCurator = async (mood: CuratorMood) => {
    setSelectedMood(mood);
    setLoading(true);
    setRecommendation(null);
    const result = await getCuratorRecommendation(mood);
    setRecommendation(result);
    setLoading(false);
  };

  return (
    <div className="pt-10 pb-20 px-4 max-w-5xl mx-auto">
      <div className="text-center mb-16">
        <h1 className="font-serif text-5xl md:text-6xl text-white mb-4">The Collection</h1>
        <p className="text-oceane-gold tracking-widest uppercase text-sm">Culinary Masterpieces</p>
      </div>

      {/* AI Curator Section */}
      <section className="mb-20 bg-gradient-to-b from-white/5 to-transparent p-8 rounded-2xl border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <Sparkles size={100} />
        </div>
        
        <h2 className="font-serif text-2xl text-white mb-6 flex items-center gap-3">
          <Sparkles className="text-oceane-gold" />
          The AI Curator
        </h2>
        <p className="text-gray-400 mb-8 max-w-2xl">
          Unsure what to choose? Select your current state of mind, and our digital sommelier will curate a full sensory experience for you—dish, wine, music, and art.
        </p>

        <div className="flex flex-wrap gap-4 mb-8">
          {Object.values(CuratorMood).map((mood) => (
            <button
              key={mood}
              onClick={() => handleCurator(mood)}
              className={`px-6 py-2 rounded-full border transition-all ${
                selectedMood === mood 
                ? 'bg-oceane-gold text-oceane-dark border-oceane-gold font-bold' 
                : 'border-white/20 text-gray-300 hover:border-white'
              }`}
            >
              {mood}
            </button>
          ))}
        </div>

        {loading && (
          <div className="flex items-center justify-center py-10">
            <Loader2 className="animate-spin text-oceane-gold h-8 w-8" />
            <span className="ml-3 text-gray-300">Consulting the muse...</span>
          </div>
        )}

        {recommendation && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-black/40 p-6 rounded-xl border border-oceane-gold/30"
          >
            <div>
              <h3 className="text-oceane-gold font-serif text-xl mb-4 italic">Your Curated Experience</h3>
              <ul className="space-y-3 text-gray-200">
                <li><strong className="text-gray-500 text-xs uppercase tracking-wider block">On the Plate</strong> {recommendation.dish}</li>
                <li><strong className="text-gray-500 text-xs uppercase tracking-wider block">In the Glass</strong> {recommendation.wine}</li>
                <li><strong className="text-gray-500 text-xs uppercase tracking-wider block">In the Air</strong> {recommendation.music}</li>
                <li><strong className="text-gray-500 text-xs uppercase tracking-wider block">On the Walls</strong> {recommendation.artStyle}</li>
              </ul>
            </div>
            <div className="flex flex-col justify-center border-l border-white/10 pl-0 md:pl-8 mt-4 md:mt-0">
              <p className="font-serif italic text-lg leading-relaxed text-gray-300">"{recommendation.reasoning}"</p>
            </div>
          </motion.div>
        )}
      </section>

      {/* Static Menu */}
      <div className="grid gap-16">
        {Object.entries(MENU_DATA).map(([category, items]) => (
          <div key={category}>
            <h3 className="font-serif text-3xl text-oceane-gold border-b border-white/10 pb-4 mb-8 capitalize">
              {category}
            </h3>
            <div className="grid gap-8">
              {items.map((item) => (
                <div key={item.id} className="flex justify-between items-baseline group">
                  <div className="flex-1 pr-8">
                    <h4 className="text-xl font-serif text-white group-hover:text-oceane-gold transition-colors">{item.name}</h4>
                    <p className="text-gray-500 text-sm mt-1 font-light">{item.description}</p>
                  </div>
                  <div className="text-xl font-serif text-white">{item.price}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Menu;