import React from 'react';
import { Link } from 'react-router-dom';
import { PerspectiveCard } from '../components/Visuals';
import { motion } from 'framer-motion';
import { ArrowRight, Music, Palette, Scale } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="relative w-full overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center px-4">
        <div className="max-w-7xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1 }}
            className="z-10 text-center lg:text-left"
          >
            <h2 className="text-oceane-gold uppercase tracking-[0.2em] mb-4 text-sm font-bold">Frankfurt am Main</h2>
            <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-bold leading-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white via-gray-200 to-gray-400">
              Taste the <br/> Revolution
            </h1>
            <p className="text-gray-300 text-lg md:text-xl mb-8 max-w-lg mx-auto lg:mx-0 font-light leading-relaxed">
              Océane is not just a restaurant. It is a dialogue between the culinary arts, political discourse, and visual mastery. 
              Immerse yourself in an atmosphere where every bite is a statement.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link to="/reservations" className="group px-8 py-4 bg-oceane-gold text-oceane-dark font-bold tracking-wider hover:bg-white transition-all duration-300 flex items-center justify-center gap-2">
                RESERVE A TABLE
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link to="/menu" className="px-8 py-4 border border-white/20 hover:border-oceane-gold hover:text-oceane-gold transition-all duration-300 tracking-wider">
                VIEW MENU
              </Link>
            </div>
          </motion.div>

          <div className="relative h-[500px] w-full hidden lg:block">
            <PerspectiveCard className="absolute top-10 right-0 w-80 h-96 z-20">
              <div className="w-full h-full bg-cover bg-center rounded-lg shadow-2xl border border-white/10" style={{ backgroundImage: "url('https://picsum.photos/400/600?grayscale')" }}>
                <div className="absolute inset-0 bg-black/30 flex items-end p-6">
                  <span className="font-serif text-2xl italic text-white">The Art</span>
                </div>
              </div>
            </PerspectiveCard>
            
            <PerspectiveCard className="absolute top-32 right-60 w-80 h-96 z-10">
              <div className="w-full h-full bg-cover bg-center rounded-lg shadow-2xl border border-white/10" style={{ backgroundImage: "url('https://picsum.photos/401/601?grayscale')" }}>
                 <div className="absolute inset-0 bg-black/30 flex items-end p-6">
                  <span className="font-serif text-2xl italic text-white">The Space</span>
                </div>
              </div>
            </PerspectiveCard>
          </div>
        </div>
      </section>

      {/* Pillars Section */}
      <section className="py-24 bg-black/20 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h3 className="font-serif text-3xl md:text-4xl text-oceane-gold mb-16">Our Three Pillars</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { icon: Palette, title: "Art", desc: "Curated exhibits surround you. The plate is merely the first canvas." },
              { icon: Music, title: "Music", desc: "Live avant-garde jazz and classical scores that challenge and soothe." },
              { icon: Scale, title: "Politics", desc: "A space fostering open dialogue. Democracy tastes better with wine." }
            ].map((item, idx) => (
              <motion.div 
                key={idx}
                whileHover={{ y: -10 }}
                className="p-8 border border-white/5 bg-white/5 rounded-sm hover:bg-white/10 transition-colors"
              >
                <item.icon className="w-12 h-12 text-oceane-gold mx-auto mb-6" />
                <h4 className="text-xl font-serif font-bold mb-4">{item.title}</h4>
                <p className="text-gray-400 font-light">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;