import React from 'react';

const Manifesto: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-20 bg-oceane-dark">
      <div className="max-w-2xl text-center border-y-2 border-oceane-gold py-12">
        <h1 className="font-serif text-4xl md:text-6xl text-white mb-8 uppercase tracking-widest">The Manifesto</h1>
        <div className="space-y-6 text-gray-300 font-serif text-xl italic leading-relaxed">
          <p>"We hold these truths to be self-evident: that all flavors are created equal, but some require more butter."</p>
          <p>"In a world of fast food and faster opinions, we choose to slow down. To chew. To listen."</p>
          <p>"Océane is a sovereign state of taste. Here, the only currency is conversation, and the only law is quality."</p>
          <p>"Leave your prejudice at the door, but bring your hunger."</p>
        </div>
        <div className="mt-12 text-oceane-gold text-sm tracking-[0.3em]">EST. 2024</div>
      </div>
    </div>
  );
};

export default Manifesto;