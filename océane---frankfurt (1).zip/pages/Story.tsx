import React from 'react';
import { FloatingImage } from '../components/Visuals';
import { motion } from 'framer-motion';

const Story: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div>
          <h1 className="font-serif text-5xl text-white mb-8">A Tale of Two Cities</h1>
          <div className="space-y-6 text-gray-300 font-light text-lg leading-relaxed">
            <p>
              Born from the vibrant chaos of Paris and the structured elegance of Frankfurt, 
              <strong>Océane</strong> was founded in 2024 by Chef Elena Vance and Political Historian Marcus Thorne.
            </p>
            <p>
              They envisioned a space where the dinner table returns to its roots as the ultimate forum for debate.
              The restaurant sits in a restored 19th-century bank vault, a nod to Frankfurt's financial heart, 
              now repurposed to hold wealth of a different kind: culture.
            </p>
            <p>
              "We believe that a society that stops arguing is a society that stops thinking. And one that stops eating well has simply given up on joy."
            </p>
            <p className="italic text-oceane-gold">
              — Marcus Thorne, Co-founder
            </p>
          </div>
        </div>
        <div className="relative h-[600px] w-full">
           <div className="absolute top-0 right-0 w-3/4 h-3/4 z-10">
              <FloatingImage src="https://picsum.photos/600/800?grayscale" alt="Chef Elena" delay={0} />
           </div>
           <div className="absolute bottom-0 left-0 w-2/3 h-2/3 z-20">
              <FloatingImage src="https://picsum.photos/500/500?grayscale&blur=2" alt="Restaurant Interior" delay={1.5} />
           </div>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mt-32 text-center max-w-3xl mx-auto"
      >
        <h2 className="font-serif text-3xl text-oceane-gold mb-6">The Architecture of Sound</h2>
        <p className="text-gray-400">
          The acoustics of Océane are engineered to allow privacy at your table while carrying the live cello notes to every corner.
          The walls are adorned with 3D-printed acoustic panels that mimic the topography of the ocean floor.
        </p>
      </motion.div>
    </div>
  );
};

export default Story;