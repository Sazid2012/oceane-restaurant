import React from 'react';
import { PerspectiveCard } from '../components/Visuals';

const EVENTS = [
  { date: "Oct 12", title: "Modernist Jazz Night", subtitle: "Trio Noir performing live", img: "https://picsum.photos/400/300?random=1" },
  { date: "Oct 15", title: "Sculpture Unveiling", subtitle: "Artist: Klaus Weber", img: "https://picsum.photos/400/300?random=2" },
  { date: "Oct 20", title: "Debate & Dine", subtitle: "Topic: The Future of Europe", img: "https://picsum.photos/400/300?random=3" }
];

const Gallery: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <h1 className="font-serif text-5xl text-white text-center mb-16">Arts & Events</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {EVENTS.map((evt, idx) => (
          <PerspectiveCard key={idx} className="h-96 w-full">
            <div className="relative w-full h-full rounded-xl overflow-hidden group">
              <img src={evt.img} alt={evt.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale group-hover:grayscale-0" />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent flex flex-col justify-end p-6">
                <span className="text-oceane-gold font-bold tracking-widest text-xs mb-2">{evt.date}</span>
                <h3 className="text-white font-serif text-2xl mb-1">{evt.title}</h3>
                <p className="text-gray-400 text-sm">{evt.subtitle}</p>
              </div>
            </div>
          </PerspectiveCard>
        ))}
      </div>

      <div className="mt-32">
        <h2 className="font-serif text-3xl text-white mb-8 text-center">Featured Collection</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 auto-rows-[200px]">
           {[1,2,3,4,5,6,7,8].map((n) => (
             <div key={n} className={`rounded-lg overflow-hidden ${n % 3 === 0 ? 'col-span-2 row-span-2' : ''} border border-white/5`}>
               <img src={`https://picsum.photos/600/600?random=${n+10}`} alt="Art" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500 cursor-pointer" />
             </div>
           ))}
        </div>
      </div>
    </div>
  );
};

export default Gallery;