import { GoogleGenAI, Type } from "@google/genai";
import { CuratorMood, CuratorRecommendation } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getCuratorRecommendation = async (mood: CuratorMood): Promise<CuratorRecommendation | null> => {
  if (!process.env.API_KEY) {
    console.warn("Gemini API Key is missing.");
    return {
      dish: "Sole Meunière",
      wine: "Sancerre 2019",
      music: "Claude Debussy - La Mer",
      artStyle: "Impressionism",
      reasoning: "API key missing, serving our signature classic."
    };
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `I am a guest at Océane, a high-end restaurant in Frankfurt with themes of Art, Politics, and Music. 
      I am feeling ${mood}. Suggest a pairing of a dish, a wine, a piece of classical or jazz music, and an art style that matches my mood and the restaurant's sophisticated vibe.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            dish: { type: Type.STRING, description: "Name of an elegant dish" },
            wine: { type: Type.STRING, description: "A specific wine pairing" },
            music: { type: Type.STRING, description: "A specific musical piece" },
            artStyle: { type: Type.STRING, description: "An art movement or style" },
            reasoning: { type: Type.STRING, description: "A short, poetic explanation of why this fits the mood." }
          },
          required: ["dish", "wine", "music", "artStyle", "reasoning"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as CuratorRecommendation;
    }
    return null;
  } catch (error) {
    console.error("Gemini Curator Error:", error);
    return null;
  }
};