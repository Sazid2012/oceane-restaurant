import React, { useState } from 'react';
import { NavItem } from '../types';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Anchor } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const NAV_ITEMS: NavItem[] = [
  { label: 'Home', path: '/' },
  { label: 'Menu', path: '/menu' },
  { label: 'Story', path: '/story' },
  { label: 'Gallery', path: '/gallery' },
  { label: 'Manifesto', path: '/manifesto' },
  { label: 'Reservations', path: '/reservations' },
];

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  return (
    <nav className="fixed w-full z-50 bg-oceane-dark/80 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex-shrink-0 flex items-center space-x-2">
             <Anchor className="text-oceane-gold h-8 w-8" />
             <span className="font-serif text-2xl font-bold tracking-widest text-white">OCÉANE</span>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              {NAV_ITEMS.map((item) => (
                <Link
                  key={item.label}
                  to={item.path}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-300 ${
                    location.pathname === item.path
                      ? 'text-oceane-gold border-b-2 border-oceane-gold'
                      : 'text-gray-300 hover:text-white hover:border-b-2 hover:border-gray-500'
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>

          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-oceane-blue focus:outline-none"
            >
              {isOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-oceane-dark border-b border-white/10"
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {NAV_ITEMS.map((item) => (
                <Link
                  key={item.label}
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    location.pathname === item.path
                      ? 'text-oceane-gold bg-oceane-blue'
                      : 'text-gray-300 hover:text-white hover:bg-oceane-blue'
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export const Footer: React.FC = () => {
  return (
    <footer className="bg-oceane-dark border-t border-white/5 py-12 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
        <div>
          <h3 className="font-serif text-xl text-oceane-gold mb-4">OCÉANE</h3>
          <p className="text-gray-400 text-sm">
            Kaiserhofstraße 12<br />
            60313 Frankfurt am Main<br />
            Germany
          </p>
        </div>
        <div>
          <h3 className="font-serif text-xl text-oceane-gold mb-4">Hours</h3>
          <p className="text-gray-400 text-sm">
            Tue - Sat: 18:00 - 02:00<br />
            Sun: Brunch 10:00 - 15:00<br />
            Mon: Closed for Art Curation
          </p>
        </div>
        <div>
          <h3 className="font-serif text-xl text-oceane-gold mb-4">Contact</h3>
          <p className="text-gray-400 text-sm">
            +49 69 1234 5678<br />
            reservations@oceane-frankfurt.de
          </p>
        </div>
      </div>
      <div className="mt-8 text-center text-gray-600 text-xs">
        &copy; {new Date().getFullYear()} Océane Frankfurt. A Symphony of Taste and Thought.
      </div>
    </footer>
  );
};